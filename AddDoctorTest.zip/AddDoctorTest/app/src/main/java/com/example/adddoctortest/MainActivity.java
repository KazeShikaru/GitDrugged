package com.example.adddoctortest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static String pid = "";
    public static ArrayList<UserObject> user = new ArrayList<UserObject>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onIDAddClicked(android.view.View view) {
        Intent intent = new Intent(this, IDAddActivity.class);
        startActivity(intent);
    }

    public void onQRAddClicked(android.view.View view) {
        Intent intent = new Intent(this, QRAddActivity.class);
        startActivity(intent);
    }

    public void onBackClicked(android.view.View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
