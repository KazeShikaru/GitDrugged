package com.example.adddoctortest;

public class UserObject {
    public String name;
    public String userId;

    public UserObject(String n, String id) {
        name = n;
        userId = id;
    }
}