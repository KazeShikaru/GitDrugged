package com.example.yourdrugs;

import java.util.ArrayList;

public class DrugData {
    public String name = "";
    public int days = 0; //days to take drug
    public int Frequency = 0;
    public int imageID = 0;

//CUSTOM FREQUENCY
    public ArrayList<Integer> times = new ArrayList<>(); //time in minutes from midnight




}
