package com.example.yourdrugs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.List;

public class YourDrugs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.your_drugs);
    }

    protected  void onResume() {
        super.onResume();
        ViewGroup list = findViewById(R.id.drug_list);
        list.removeAllViews();


        Gson gson = new Gson();
        List<DrugData> datas = null;
        String fileName = "drugs.json";
        String inJson = null;
        Type listType = new TypeToken<List<DrugData>>(){}.getType();
        try {
            InputStream in = openFileInput(fileName);
            int size = in.available();
            byte[] buffer = new byte[size];
            in.read(buffer);
            in.close();
            inJson = new String(buffer, "UTF-8");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

        if(inJson != null) {
            datas = gson.fromJson(inJson, listType);
            for(DrugData data : datas) {
                TextView view = new TextView(this);
                final float scale = this.getResources().getDisplayMetrics().density;
                int pixels = (int) (80 * scale + 0.5f);

                view.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,pixels));
                view.setText(data.name);
                view.setTextSize(40);
                view.setPadding(20,0,0,0);
                view.setGravity(Gravity.CENTER_VERTICAL);
                view.setBackground(getDrawable(R.drawable.back_rec_black));
                list.addView(view);
            }
        }
    }

    public void addDrug(View v) {
        Intent intent = new Intent(this, AddDrug.class);
        startActivity(intent);
    }






}
