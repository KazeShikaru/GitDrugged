package com.example.gitdrugged;

import android.annotation.TargetApi;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;

public class Notification extends Application {
    public static final String ChannelOneId = "c1";
    public static final String ChannelTwoId = "c2";
    public static final String ChannelThreeId = "c3";
    public static final String ChannelFourId = "c4";

    @Override
    public void onCreate(){

        super.onCreate();
        createNotifChanel();
    }

    @TargetApi(26)
    public void createNotifChanel(){

        if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.O){
            NotificationChannel ch1 = new NotificationChannel(
                    ChannelOneId,"FirstNotif", NotificationManager.IMPORTANCE_HIGH
            );
            ch1.setDescription("First chanel used for providing medical reminders");

        }

    }

    NotificationManager man = getSystemService(NotificationManager.class);
    man.createNotificationChannel();

}
